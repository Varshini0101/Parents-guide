import React, { useState } from 'react';
import { Search, Book, Calculator, TestTube2, Globe2, Clock3, BookOpen, ArrowRight, Lightbulb, Users, MessageSquare, Target, Trophy, CheckCircle2 } from 'lucide-react';

type Subject = {
  name: string;
  icon: React.ReactNode;
  color: string;
  topics: string[];
};

const subjects: Subject[] = [
  {
    name: 'Mathematics',
    icon: <Calculator className="w-6 h-6" />,
    color: 'bg-gradient-to-br from-blue-500 to-blue-600',
    topics: ['Algebra', 'Geometry', 'Fractions', 'Basic Arithmetic']
  },
  {
    name: 'Science',
    icon: <TestTube2 className="w-6 h-6" />,
    color: 'bg-gradient-to-br from-green-500 to-green-600',
    topics: ['Biology', 'Chemistry', 'Physics', 'Earth Science']
  },
  {
    name: 'Social Studies',
    icon: <Globe2 className="w-6 h-6" />,
    color: 'bg-gradient-to-br from-purple-500 to-purple-600',
    topics: ['History', 'Geography', 'Civics', 'Economics']
  },
  {
    name: 'Language Arts',
    icon: <Book className="w-6 h-6" />,
    color: 'bg-gradient-to-br from-red-500 to-red-600',
    topics: ['Reading', 'Writing', 'Grammar', 'Literature']
  }
];

function App() {
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-white shadow-lg border-b border-indigo-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-indigo-600 to-purple-600 p-2 rounded-lg">
                <BookOpen className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 text-transparent bg-clip-text">
                ParentScholar
              </h1>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search any topic..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-full w-64 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-12 text-white">
          <h2 className="text-4xl font-bold mb-6">
            Learn Together, Grow Together
          </h2>
          <p className="text-xl text-indigo-100 max-w-2xl mx-auto mb-8">
            Transform homework time into quality time with our collaborative learning space for parents and children.
          </p>
          <button className="bg-white text-indigo-600 px-8 py-3 rounded-full font-semibold hover:bg-indigo-50 transition-colors">
            Start Collaborating
          </button>
        </div>

        {/* Collaboration Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-indigo-100">
            <div className="bg-gradient-to-br from-pink-500 to-rose-600 w-12 h-12 rounded-full flex items-center justify-center text-white mb-4">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Real-time Collaboration</h3>
            <p className="text-gray-600">Work together in a shared digital workspace, solving problems side by side.</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-indigo-100">
            <div className="bg-gradient-to-br from-orange-500 to-amber-600 w-12 h-12 rounded-full flex items-center justify-center text-white mb-4">
              <MessageSquare className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Interactive Notes</h3>
            <p className="text-gray-600">Share notes, explanations, and feedback in real-time as you learn together.</p>
          </div>
          <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow border border-indigo-100">
            <div className="bg-gradient-to-br from-green-500 to-emerald-600 w-12 h-12 rounded-full flex items-center justify-center text-white mb-4">
              <Target className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Progress Tracking</h3>
            <p className="text-gray-600">Monitor learning achievements and celebrate milestones together.</p>
          </div>
        </div>

        {/* Subjects Grid */}
        <h3 className="text-2xl font-bold text-gray-900 mb-6">Explore Subjects</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {subjects.map((subject) => (
            <button
              key={subject.name}
              onClick={() => setSelectedSubject(subject)}
              className={`p-6 rounded-xl shadow-sm hover:shadow-md transition-all transform hover:-translate-y-1
                ${selectedSubject?.name === subject.name ? 'ring-2 ring-indigo-500' : 'bg-white'}`}
            >
              <div className={`${subject.color} w-12 h-12 rounded-full flex items-center justify-center text-white mb-4`}>
                {subject.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{subject.name}</h3>
              <p className="text-sm text-gray-500">
                Quick guides and explanations
              </p>
              <ArrowRight className="w-5 h-5 text-gray-400 mt-4" />
            </button>
          ))}
        </div>

        {/* Selected Subject Content */}
        {selectedSubject && (
          <div className="bg-white rounded-xl shadow-sm p-8 border border-indigo-100">
            <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
              <span className={`${selectedSubject.color} p-2 rounded-full mr-3 text-white`}>
                {selectedSubject.icon}
              </span>
              {selectedSubject.name} Topics
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {selectedSubject.topics.map((topic) => (
                <div key={topic} className="border border-indigo-100 rounded-lg p-4 hover:bg-indigo-50 cursor-pointer transition-colors">
                  <div className="flex items-center">
                    <Lightbulb className="w-5 h-5 text-yellow-500 mr-2" />
                    <h4 className="text-lg font-medium text-gray-900">{topic}</h4>
                  </div>
                  <p className="text-sm text-gray-500 mt-2">
                    Click to explore {topic.toLowerCase()} concepts and examples
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Achievement Section */}
        <div className="mt-12 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-xl p-8">
          <div className="flex items-center mb-6">
            <Trophy className="w-8 h-8 text-yellow-500 mr-3" />
            <h3 className="text-2xl font-bold text-gray-900">Learning Achievements</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-indigo-100">
              <div className="flex items-center mb-4">
                <CheckCircle2 className="w-6 h-6 text-green-500 mr-2" />
                <h4 className="font-semibold text-gray-900">Daily Streak</h4>
              </div>
              <p className="text-3xl font-bold text-indigo-600">5 Days</p>
              <p className="text-sm text-gray-500 mt-2">Keep up the momentum!</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-indigo-100">
              <div className="flex items-center mb-4">
                <Target className="w-6 h-6 text-blue-500 mr-2" />
                <h4 className="font-semibold text-gray-900">Topics Mastered</h4>
              </div>
              <p className="text-3xl font-bold text-indigo-600">12</p>
              <p className="text-sm text-gray-500 mt-2">Great progress!</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow-sm border border-indigo-100">
              <div className="flex items-center mb-4">
                <Clock3 className="w-6 h-6 text-purple-500 mr-2" />
                <h4 className="font-semibold text-gray-900">Study Time</h4>
              </div>
              <p className="text-3xl font-bold text-indigo-600">3.5 hrs</p>
              <p className="text-sm text-gray-500 mt-2">This week</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;